package com.example.calkulator;

import android.content.Intent;
import android.icu.text.IDNA;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    Button button7;
    Button button8;
    Button button9;

    Button buttonDel;
    Button buttonUp;
    Button buttonDelit;
    Button buttonx;
    Button buttonC;
    Button buttonrovno;
    TextView info;
    TextView info1;
    TextView info2;
    private String text="";
    private String text1="";
    private String text2="";
    private  int a;
    private  int b;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            info = findViewById(R.id.info);

            button0 = findViewById(R.id.button0);
            button1 = findViewById(R.id.button1);
            button2 = findViewById(R.id.button2);
            button3 = findViewById(R.id.button3);
            button4 = findViewById(R.id.button4);
            button5 = findViewById(R.id.button5);
            button6 = findViewById(R.id.button6);
            button7 = findViewById(R.id.button7);
            button8 = findViewById(R.id.button8);
            button9 = findViewById(R.id.button9);

            buttonDel = findViewById(R.id.buttonDel);
            buttonUp = findViewById(R.id.buttonUp);
            buttonDelit = findViewById(R.id.buttonDelit);
            buttonx = findViewById(R.id.buttonx);
            buttonC = findViewById(R.id.buttonC);
            buttonrovno = findViewById(R.id.buttonrovno);



            button0.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"0";
                        text = text + "0";
                        info.setText(text);
                    }
                    else {
                        text = text + "0";
                        info.setText(text);
                    }

                }
            });
            button1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"1";
                        text = text + "1";
                        info.setText(text);
                    }
                    else {
                        text = text + "1";
                        info.setText(text);
                    }
                }
            });
            button2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"2";
                        text = text + "2";
                        info.setText(text);
                    }
                    else {
                        text = text + "2";
                        info.setText(text);
                    }
                }
            });
            button3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"3";
                        text = text + "3";
                        info.setText(text);
                    }
                    else {
                        text = text + "3";
                        info.setText(text);
                    }
                }
            });
            button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"4";
                        text = text + "4";
                        info.setText(text);
                    }
                    else {
                        text = text + "4";
                        info.setText(text);
                    }
                }
            });
            button5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"5";
                        text = text + "5";
                        info.setText(text);
                    }
                    else {
                        text = text + "5";
                        info.setText(text);
                    }
                }
            });
            button6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"6";
                        text = text + "6";
                        info.setText(text);
                    }
                    else {
                        text = text + "6";
                        info.setText(text);
                    }
                }
            });
            button7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"7";
                        text = text + "7";
                        info.setText(text);
                    }
                    else {
                        text = text + "7";
                        info.setText(text);
                    }
                }
            });
            button8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"8";
                        text = text + "8";
                        info.setText(text);
                    }
                    else {
                        text = text + "8";
                        info.setText(text);
                    }
                }
            });
            button9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(text2 == "-" || text2 == "/" || text2 == "x" || text2 == "+")
                    {
                        text1=text1+"9";
                        text = text + "9";
                        info.setText(text);
                    }
                    else {
                        text = text + "9";
                        info.setText(text);
                    }
                }
            });
            buttonUp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (text2 != "+" && text2 != "-" && text2 != "/" && text2 != "x") {
                        a = Integer.parseInt(text);
                        text2 = "+";
                        text = text + "+";
                        info.setText(text);
                    }


                }
            });
            buttonx.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (text2 != "+" && text2 != "-" && text2 != "/" && text2 != "x") {
                        a = Integer.parseInt(text);
                        text2 = "x";
                        text = text + "x";
                        info.setText(text);
                    }
                }
            });
            buttonDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (text2 != "+" && text2 != "-" && text2 != "/" && text2 != "x") {
                        a = Integer.parseInt(text);
                        text2 = "-";
                        text = text + "-";
                        info.setText(text);
                    }
                }
            });
            buttonDelit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (text2 != "+" && text2 != "-" && text2 != "/" && text2 != "x") {
                        a = Integer.parseInt(text);
                        text2 = "/";
                        text = text + "/";
                        info.setText(text);
                    }
                }
            });
            buttonC.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    a = 0;
                    b = 0;
                    text = "";
                    info.setText(text);

                }
            });
            buttonrovno.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    b = Integer.parseInt(text1);


                    if (text2 == "+") {

                        text2 = "";
                        text = Integer.toString(a + b);
                        a = 0;
                        b = 0;
                        text1 = "";
                        info.setText(text);
                    } else if (text2 == "-") {

                        text = Integer.toString(a - b);
                        text2 = "";
                        a = 0;
                        b = 0;
                        text1 = "";
                        info.setText(text);
                    } else if (text2 == "/") {

                        text = Integer.toString(a / b);
                        text2 = "";
                        a = 0;
                        b = 0;
                        text1 = "";
                        info.setText(text);
                    } else if (text2 == "x") {

                        text = Integer.toString(a * b);
                        text2 = "";
                        a = 0;
                        b = 0;
                        text1 = "";
                        info.setText(text);
                    }

                }
            });
            return insets;
        });



    }

}